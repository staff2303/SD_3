package com.peisia.domain;

import lombok.Data;

@Data
public class GuestVO {
	private Long bno;
	private String btext;
}
