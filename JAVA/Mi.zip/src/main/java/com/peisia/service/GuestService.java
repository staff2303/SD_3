package com.peisia.service;

public interface GuestService {

}
