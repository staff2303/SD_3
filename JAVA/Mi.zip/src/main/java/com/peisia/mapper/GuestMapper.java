package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.domain.GuestVO;

public interface GuestMapper {
	public ArrayList<GuestVO> getList();
}
